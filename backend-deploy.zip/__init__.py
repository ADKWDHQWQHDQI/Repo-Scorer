"""Repository Scorer - Intelligent repo quality assessment with AZURE OPENAI"""

__version__ = "0.1.0"
